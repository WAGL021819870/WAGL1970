package com.qualitytest.chocair;

import static org.junit.Assert.assertEquals;

import java.awt.Dimension;
import java.awt.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchJobTest {

	private WebDriver driver;
	By registerLinkLocator = By.linkText("Empleos");
	By registerPageLocator = By.id("menu-item-550");
	By reproducirvideoLocator = By.linkText(
			"https://www.youtube.com/embed/JJOe-ox3fiY?feature=oembed&amp;start&amp;end&amp;wmode=opaque&amp;loop=0&amp;controls=1&amp;mute=0&amp;rel=0&amp;modestbranding=0");
	By generalsoftLocator = By.className("elementor-text-editor elementor-clearfix");
	By enginersoftLocator = By.className("elementor-text-editor elementor-clearfix");
	By formSearchLocator = By.name("search_keywords");
	By formBTNSearchLocator = By.name("Search Jobs");

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.choucairtesting.com/");
	}

	@Test
	public void clickEmpleo() throws InterruptedException {
		driver.findElement(registerLinkLocator).click();
		Thread.sleep(2000);
		if (driver.findElement(registerLinkLocator).isDisplayed()) {
			driver.findElement(reproducirvideoLocator).click();
			driver.navigate().back();
		} else {
			System.out.print("Error al ejecutar video");
		}
	}

	@Test
	public void softJobs() throws InterruptedException {
		driver.findElement(registerLinkLocator).click();
		if (driver.findElement(registerLinkLocator).isDisplayed()) {
			driver.findElement(By.linkText("Fundamentos ingenieria de software")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Marcos de trabajo de software: �giles/tradicionales")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Principios de programaci�n")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Algoritmos de software")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("�Qu� es programaci�n por Ncapas")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Los errores del software")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Manual Practico de SQL")).click();
			driver.navigate().back();
		} else {
			System.out.print("Error al abrir link");
		}
	}
	
	
	
	@Test
	public void naveJobs() throws InterruptedException {
		driver.findElement(registerLinkLocator).click();
		if (driver.findElement(generalsoftLocator).isDisplayed()) {
			driver.findElement(By.linkText("Modelo de calidad de software")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Diferencia entre calidad de software y pruebas")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Papel de los ingenieros")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("El software en la econom�a actual")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Calidad de software")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Los errores del software")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Fundamentos ingenier�a de software")).click();
			driver.navigate().back();
		} else {
			System.out.print("Error al abrir link");
		}
	}
	
	
	@Test
	public void qaJobs() throws InterruptedException {
		driver.findElement(registerLinkLocator).click();
		if (driver.findElement(generalsoftLocator).isDisplayed()) {
			driver.findElement(By.linkText("Marcos de trabajo de pruebas")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("�Qu� son los riesgos del proyecto y de producto?")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("T�cnicas de caja negra")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("Foundation Level - T�cnicas")).click();
			driver.navigate().back();
		} else {
			System.out.print("Error al abrir link");
		}
	}
	
	
	@Test
	public void gerenciaJobs() throws InterruptedException {
		driver.findElement(registerLinkLocator).click();
		if (driver.findElement(generalsoftLocator).isDisplayed()) {
			driver.findElement(By.linkText("Fundamentos de la gerencia de proyectos en desarrollo de Software")).click();
			driver.navigate().back();
			driver.findElement(By.linkText("�Cu�les son las actividades de la Gesti�n de Proyectos?")).click();
			driver.navigate().back();

		} else {
			System.out.print("Error al abrir link");
			
		}
	}
	
	
	@Test
	public void searchJobs() {
		driver.findElement(registerLinkLocator).click();
		if (driver.findElement(registerLinkLocator).isDisplayed()) {
			driver.findElement(formSearchLocator).sendKeys("Analista");
			driver.findElement(formBTNSearchLocator).click();
		
		}
		else {
			System.out.print("No se encuentran resultados");
		}
		
		
	}
	
	
	

	@After
	public void tearDown() {

		driver.quit();
	}

}
